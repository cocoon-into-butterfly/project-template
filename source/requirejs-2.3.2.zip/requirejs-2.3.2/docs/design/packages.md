# Packages

Moved to [pkg project](http://github.com/requirejs/pkg/blob/master/docs/design/packages.md)
