define({
    name: 'b'
});

