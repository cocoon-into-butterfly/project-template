define(function (require, exports) {
    exports.name = 'greek';
});