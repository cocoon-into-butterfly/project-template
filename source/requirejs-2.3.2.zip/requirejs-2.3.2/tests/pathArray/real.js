define({
    name: 'real'
});
