define(['./pane'], function (pane) {
    return {
        name: 'dojox/window',
        paneName: pane.name
    };
});
